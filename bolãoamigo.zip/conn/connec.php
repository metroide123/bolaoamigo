<?php

$sevidor = "localhost";
$user = "root";
$pass = "";
$DBNAME = "test";

//$sevidor = "localhost";
//$user = "id14507862_bd_bolao";
//$pass = "G{Ka}^?Pf*?LvA1?";
//$DBNAME = "id14507862_bd_teste";

$con = mysqli_connect($sevidor, $user, $pass, $DBNAME);
